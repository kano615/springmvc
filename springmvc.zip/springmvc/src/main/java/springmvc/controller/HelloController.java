package springmvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController {

    @RequestMapping("/hello")
    public String display() {
        System.out.println("inside hello");
        return "/index";
    }

    @RequestMapping("/about")
    public String about(Model model) {
    	List<String> friendS=new ArrayList<String>();
    	friendS.add("kuldip");
    	friendS.add("bhardwaj");
    	friendS.add("jaiman");
    	friendS.add("rudraraj");
    	friendS.add("mayank");
    	model.addAttribute("friends",friendS);
       
     
        return "/about";
    }

}
